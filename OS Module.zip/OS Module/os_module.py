## OS Module in Python 

# Built in module in python to interact with ooerating system 

import os 

if (not os.path.exists("data")):
    os.mkdir("data")

# To make folders 100 folders under data folder 
# for i in range(1,101):
#     os.mkdir(f"data/Day {i}")

# Renaming the folders 
for i in range(1,101):
    os.rename(f"data/Day {i}", f"data/ Program {i}")


# os has lot of functions, you can use it as and when required by using documentation and also google
# and in projects depending on requirements 

# os.getcwd - Tells us which directory we are working in 
# os.chdir - to change your directory 


# os.remove() - remove a file 
# os.rdir() - remove a directory 
