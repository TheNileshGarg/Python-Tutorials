# List all the folders in a directory 
import os

folders = os.listdir("data")
print(folders)

# you can also list files under each folder in data 
